import React, { Component, Fragment } from "react";
var res = [];
class Mapping extends Component {
	constructor(props) {
		super(props);
	}
	render() {
		// console.log(res[0]);
		// console.log(this.props.keys + " and " + expression);
		return (
			<Fragment>
				<table
					key={this.props.keys}
					style={{
						border: "solid 2px black",
						height: "2px",
						width: "2px",
						BackgroundColor: "black"
					}}
				>
					<tbody key={this.props.keys}>
						<tr>
							<td>{this.props.keys}</td>

							<td>{this.props.value}</td>
						</tr>
					</tbody>
				</table>
				<table
					key={this.props.keys}
					style={{
						border: "dotted 2px black",
						height: "4px",
						width: "4px",
						BackgroundColor: "black"
					}}
				>
					<tbody key={this.props.keys}>
						<tr>THIS IS AVERAGE EXPRESSION OF CLASS</tr>
						<tr>
							<td>{this.props.avg}</td>
						</tr>
					</tbody>
				</table>
			</Fragment>
		);
	}
}
export default Mapping;
